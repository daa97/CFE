

                      README FOR MAKELIB


The makelib.f code converts the formatted form of the thermodynamic and 
transport property databases to an unformatted form for use in programs like
SUBEQ and CEA or CEA2.


A complete description for using this program is given in the comments in the
FORTRAN source program (i.e. makelib.f).  Compilers are freely available on the
internet for any computer platform. 

If you have any questions, contact Russell.W.Claus@nasa.gov
