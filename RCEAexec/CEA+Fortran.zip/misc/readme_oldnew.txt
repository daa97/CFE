         
     
                        README FOR OLDNEW
         
          
The code oldnew.f comverts the NASA Glenn thermodynamic coefficient 
data in the old format to the new format.  In the old format Cp was fitted 
to a fourth-order polynomial while the new format has an empirical form with 
two extra terms.  After conversion the coefficients for these extra terms 
will be zero.
         
Descriptions of input and output are given in the comments in the 
FORTRAN code.  
         
FORTRAN compilers are freely available on the internet for various 
Computer platforms.

If you have any questions, please contact Russell.W.Claus@nasa.gov
